# Ecosistemi & Biomi — Linee Guida Evo Tactics

Questo documento spiega come modelliamo i biomi, le specie e le reti trofiche e come si collegano a Jobs/Tribe/Mate, loot e bilanciamento.

## 1. Strati del modello
- **Abiòtico**: luce, temperatura, acqua, suolo, aria, nutrienti, pH, salinità.
- **Biòtico**: produttori → consumatori (primari/secondari/terziari) → decompositori; reti non lineari, controlli bottom-up/top-down, cascade.
- **Gruppi funzionali**: predatori, erbivori, impollinatori, dispersori, simbionti, parassiti/parasitoidi, detritivori, decompositori, filtratori, ingegneri, specie chiave, ombrello/indicatrici, invasive.

## 2. Dati principali
- `data/biomes/*.yaml`: parametri di bioma, hazards, preferenze Jobs, servizi ecosistemici, metriche.
- `data/species/*.yaml`: specie e parti morfologiche (catalogo + file per specie).
- `data/foodweb/*.yaml`: nodi/archi/controlli/cascade per bioma.

## 3. Collegamenti di gameplay
- **Jobs/Tribe/Mate**: ogni specie ha `jobs_synergy` e `mate_synergy`. Ogni bioma fornisce `preferences.jobs` e tag tribali (WIP).
- **Loot/Craft**: specie e biomi aggiungono `loot_tags` e `services` per ricette e drop. Rarità/Spawn dipendono da `balancing_metrics`.
- **VC indices** (aggro, risk, cohesion, setup, explore, tilt): usati per tuning di incontri, pathing e AI.

## 4. Consistenza & Validazione
- Ogni specie deve avere biomi validi; ogni bioma deve referenziare almeno 1 foodweb.
- Tag coerenti e caps DR/Res rispettano `global_rules.stacking_caps`.
- TBD: validatori (TS/Py) per schema e link.

## 5. Esempio — Badlands (Brulle Terre Ferrose)
Vedi `data/biomes/badlands.yaml`, `data/species/dune_stalker.yaml`, `data/foodweb/BADLANDS.yaml`.
