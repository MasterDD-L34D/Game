# Data Schemas

## neurons_*.csv
Columns:
- `code` (string) — in-game neuron code (e.g., "SO 06", "SS 10-2").
- `name` (string) — neuron name.
- `branch` (string) — neuronal branch (exact fandom label).
- `genetic` ("Yes"/"No") — whether it is a genetic mutation.
- `unlock_trigger` (string) — short actionable description.
- `effect_short` (string) — short mechanical effect.
- `connects_from` (string) — semicolon-separated prerequisites (if known).
- `connects_to` (string) — semicolon-separated forward links (if known).

## branches_counts.json
- Official totals per branch when published on fandom.
- `None` totals are placeholders to be filled as we verify more branches.

## neurons_meta.json
- Aggregate totals for the game (297 / 208 / 89).

