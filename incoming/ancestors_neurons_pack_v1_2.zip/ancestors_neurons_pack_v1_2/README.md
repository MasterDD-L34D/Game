# Ancestors — Neuronal Data Pack v1.2 (verified)

Questo pacchetto fornisce dati verificati dal web per **Ancestors: The Humankind Odyssey**,
con focus su **Senses (37 nodi totali, 35 estratti qui)** e uno **scheletro Motricity/Ambulation**.
Pronto per essere aggiunto al tuo repo Evo Tactics / database neuroni.

## Contenuto
- `data/neurons_senses.csv` — 35/37 nodi del ramo **Senses**, con `unlock_trigger` ed `effect_short`.
- `data/neurons_motricity_core.csv` — nodi validati per standing/bipedalità (Motricity).
- `data/neurons_ambulation_partial.csv` — Ambulation seed (AB 07) per agganciare Dexterity/Motricity.
- `data/branches_counts.json` — conteggi ufficiali per ramo (Ambulation=26; Senses=37...).
- `data/neurons_meta.json` — totale globale (297 / 208 / 89).
- `schemas/SCHEMAS.md` — specifiche colonne per CSV/JSON.
- `docs/sources.md` — fonti citate e link diretti.
- `docs/validation_report.md` — cosa è stato verificato e cosa resta da completare.
- `docs/traits_sensienti.yaml` — bozza tratti "Sensienti" (T1..T5) + sistemi interocettivi.
- `docs/anthroposophy_mapping.md` — mapping tra corpus senziente (antroposofia) e sistemi sensoriali moderni.

## Import rapido nel repo
1. Unzip nella tua cartella repo (es. `data/ancestors/`).
2. Unisci `neurons_senses.csv` nel tuo database principale (chiave `code`). 
3. Integra i conteggi da `branches_counts.json` nel tuo modulo di QA.
4. Usa `traits_sensienti.yaml` per generare i nuovi tratti e sinergie.

> Nota: due nodi Senses risultano non estratti nella tabella (la pagina Fandom è parziale con rate‑limit). 
> Restano marcati come `TODO` nel report e verranno aggiunti alla prossima iterazione.

