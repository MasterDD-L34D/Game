# Validation Report — v1.2

**Obiettivo**: portare il dump neuroni verso i **297** con fonti verificate.

## Stato ramo Senses
- Totali ufficiali: 37 (31 reg., 6 mut.) — *verificato*.
- Nodi estratti in CSV: **35/37** con `unlock_trigger` ed `effect_short`.
- Mancanti: 2 (bloccati da rate‑limit della pagina Fandom). Le voci coinvolte sono memorizzazioni/velocità minori (non bloccanti per gameplay).

## Stato Ambulation/Motricity
- Ambulation totali: 26 (12 reg., 14 mut.) — *verificato conteggio*.
- Dati: aggancio `AB 07 Carrying Endurance` + core bipedalità (WA 02/03/05) in Motricity per collegare al ramo Dexterity.
- TODO: completare i rami *climb/jump/run/injury/swim‑handoff* da mappa PNG ufficiale.

## Mutazioni & Meteoriti
- Regole di induzione mutazioni e massimizzazione (12 per ciclo, adulti/anziani) — *verificate*.
- Elenco 12 **Meteorite Sites** — verificato in pagina `Meteorite Site`.

## QA automatici proposti
- Check coerenza conteggi per ramo rispetto a `branches_counts.json`.
- Lint CSV (duplicati su `code`, mismatch `genetic` vs prefisso `BB`).

