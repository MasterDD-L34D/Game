# Fonti verificate (Ott 2025)

- Fandom — **Neurons (conteggi globali e per ramo)**: https://ancestors.fandom.com/wiki/Neurons
- Fandom — **Senses (neuronal branch)** (tabella nodi + descrizioni): https://ancestors.fandom.com/wiki/Senses_%28neuronal_branch%29
- Fandom — **Senses / Hearing / Smelling / Identify** (dettagli identificazione/ricordo): 
  - https://ancestors.fandom.com/wiki/Hearing
  - https://ancestors.fandom.com/wiki/Smelling
  - https://ancestors.fandom.com/wiki/Identify
- Fandom — **Dexterity (per collegamenti a WA/AB)**: https://ancestors.fandom.com/wiki/Dexterity_%28neuronal_branch%29
- Fandom — **Stand Up (Motricity: WA 02/03/05)**: https://ancestors.fandom.com/wiki/Stand_Up
- Fandom — **Category: Neuronal Branches Maps** (mappe dettagliate Senses/Ambulation): https://ancestors.fandom.com/wiki/Category%3ANeuronal_Branches_Maps
- Fandom — **Carrying Endurance (AB 07)**: https://ancestors.fandom.com/wiki/Carrying_Endurance_%28AB_07%29
- Fandom — **Meteorite Site / Meteorite / Genetic Mutations**: 
  - https://ancestors.fandom.com/wiki/Meteorite_Site
  - https://ancestors.fandom.com/wiki/Meteorite
  - https://ancestors.fandom.com/wiki/Genetic_Mutations

## Riferimenti scientifici (sensi e interocezione)
- Wikipedia — **Sound localization**; **Jeffress model** (binaural/ITD): https://en.wikipedia.org/wiki/Sound_localization ; https://en.wikipedia.org/wiki/Lloyd_A._Jeffress
- Cell Research (Apr 2025) — **Equilibrioception (vestibolo)** GPCR LPHN2/ADGRL2: DOI 10.1038/s41422-025-01075-x

