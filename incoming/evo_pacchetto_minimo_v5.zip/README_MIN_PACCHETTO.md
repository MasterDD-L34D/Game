# Pacchetto Minimo — Evo Tactics (v5, 2025-10-24)

### Nuovo in v5
- **MBTI Gates (soft)**: `form/mbti_gates.yaml` con soglie e penalità di primo turno.
- **Schemas JSON**: `schemas/pg.schema.json`, `schemas/npg.schema.json` per convalide automatiche.
- **Spawn Pack VTT**: `exports/spawn_packs/pack_biome_jobs_v1.json` con **12 NPG** pronti.
- **Quickstart GM**: `GM_Quickstart.md` (setup → telemetria → ricompense → validazione).

Tutto integrato con contenuti delle versioni precedenti (specie/morph/biomi/jobs/traits/gear/rules/social/telemetry).

### Prossimi step suggeriti
- Aggiungere *stance* e *guardie* come moduli (`rules/stances.yaml`).
- Estendere `tags/weapon*.yaml` con 3–5 tag addizionali (Es.: *Vibrante*, *Ariosa*, *Cinetica*).
- Spawn Pack v2 con **varianti di rank** (R2) e **elite/boss**.
