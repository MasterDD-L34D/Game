# Validazione Schede (Rapido)

1) **Budget Morph**: somma costi delle parti ≤ morph_budget_max (specie).  
2) **AC/HP/Parry**: verifica con `rules/stats.md`.  
3) **Sinergie**: assicurati che gli elementi esistano (es. *backstab* presente se usi `echolocate+backstab`).  
4) **Cap Risorse**: PT/PP per turno; SG 0..3.  
5) **Job Unlocks**: abilità in linea con `pi_costs` e rank.
