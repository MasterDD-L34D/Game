# Tabelle di Comportamento del Regista

## Reazione alla Vista del Party (1d6)
1-2: Evita e osserva da lontano • 3-4: Ingaggia se in superiorità • 5: Preda isolata immediata • 6: Offerta di scambio/alleanza

## Piano se Ferito (1d6)
1: Fuga • 2: Chiede tregua • 3-4: Cambia posizione (copertura/strettoria) • 5: Chiama rinforzi • 6: All-in

## In Inferiorità Numerica (1d6)
1-2: Trattativa • 3-4: Trappola/ambush • 5: Ritirata elastica • 6: Recluta fauna locale
