# Linee Guida di Tuning (playtest-needed)

- **PT per turno**: 3 base; prova 2–4 in funzione del ritmo desiderato.
- **PP**: max 3; recupero 1/incontro + effetti (Baratto Tecnico, Scavenge).
- **SG**: scala 0..3; ricarica 1 ogni 2 colpi messi a segno; spesa per ultimate/surge potenti.
- **Percentuali a colpire**: target 60–70% su pari livello; 50–60% su elite.
- **Danni per round (DPR)**: calibra per chiudere scontri in 3–5 round medi.
- **Hazard di bioma**: impatta ~10–20% delle azioni in scena (non troppo punitivo).
