# Tabelle Piace / Non Piace (Bozza)

Esempi rapidi da usare come mod ai check social/mating:

- **Dune Stalker**
  - Piace: ambienti asciutti, posizionamento intelligente, attacchi da flanking.
  - Non Piace: rumore eccessivo vicino al nido, fuoco continuo.
- **Job matching**
  - Skirmisher apprezza alleati che preparano flanking (+1).
  - Warden apprezza chi rispetta le zone di controllo (+1).
  - Invoker non gradisce intralci in linea di tiro (-1).
