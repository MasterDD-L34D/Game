# Proficiency Armi (playtest-needed)

- **Categorie**: light-blades, focus-rod, melee-general, ranged-general, ecc.
- Se **proficiente**, non applichi penalità al colpire con quell'arma.
- Se **non proficiente**: -2 a colpire e non puoi attivare Surge specifiche dell'arma (salvo indicato).
- Alcuni **job** forniscono proficienze: vedi `jobs/*.yaml` (playtest-needed mapping dettagliato).
