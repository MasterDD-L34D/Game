# Privacy & Reset — Bozza

- **Profiling (on/off)**: se attivo, abilita suggerimenti adattivi (build, sinergie).
- **Reset disponibile**: 1/missione puoi azzerare *telemetry* e *PF_session* prima del debrief (per testing o narrativa).
- **Opt-out**: disattivando il profiling, disabiliti anche sinergie cross-modulo basate su preferenze.
