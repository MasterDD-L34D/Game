# Ecosistema — BADLANDS (Evo Tactics)

Questo pacchetto definisce un ecosistema completo per **Brulle Terre Ferrose** con produttori, consumatori, decompositori,
foodweb, metriche di bilanciamento, collegamenti a **Jobs/Tribe/Mate** e **loot/craft**.

## Ruoli ecologici → Sinergie di gioco
| Ruolo | Jobs sinergici | Mate sinergici | Effetti tipici |
|---|---|---|---|
| Predatori apicali | Skirmisher, Warden | Cacciatore, Battitore | Controllo top-down su erbivori; eventi caccia, imboscate |
| Predatori secondari | Skirmisher, Vanguard, Invoker | Ricognitore, Disturbatore | Pressione su primari; stormo/imboscate; effetti status |
| Detritivori/Filtratori | Harvester | Stabilizzatore, Fornitore | Drop reagenti; stabilizzazione dune; raccolta risorse |
| Ingegneri ecosistema | Artificer, Warden | Ingegnere, Logista | Modifica mappa (dighe, monticelli, gallerie); percorsi alternativi |
| Produttori | — (fonte risorse) | — | Resine, fibre, materiali; impatto su spawn primari |
| Decompositori | Invoker, Harvester | Netturbino | Riciclo, mineralizzazione, bonus al crafting naturale |

## Metriche VC (bioma)
- **aggro 0.60** · **risk 0.65** · **cohesion 0.40** · **setup 0.55** · **explore 0.70** · **tilt 0.50**

## Hook di scena (esempi rapidi)
- **Dighe di polvere (Mirmec Ferro)**: si formano creste che creano nuovi coperture/linee di tiro (Artificer/Warden).
- **Tempesta di risonanza (Echo Wing)**: brevi disorientamenti sonici (test equilibrio/stealth).
- **Corsa agli ossidi (Rust Scavenger)**: finestra di raccolta materiali rari ma con rischio corrosione su equip.

## File
- `data/biomes/badlands.yaml` — bioma con abiotico, hazards, services, metriche, VC.
- `data/species/*.yaml` — 10 specie con ruolo trofico, sinergie Jobs/Mate, loot_tags, spawn_rules.
- `data/foodweb/BADLANDS.yaml` — rete trofica, controlli, trigger di cascade.

> Nota: le parti morfologiche di base (spring_legs, acid_gland, ecc.) sono quelle viste negli esempi precedenti e possono essere estese.
