
# Import & Collegamento al Repo Evo Tactics

1. **Cartelle proposte** (allineate al repo attuale):
   - `ancestors/` (tutto questo pacchetto)
   - Collegare `evo_traits/*.yaml` al loader dei `morph/` se usiamo `type: senses/metabolism/intelligence`.
   - Aggiungere in `rules/checks.md` i nuovi check (Equilibrio, Interocezione).

2. **Database**
   - Caricare `schema/*.yaml` e `schema/feats.csv` in un DB o in un loader YAML→in‑memory.
   - Inserire campi `source_*` per la tracciabilità delle fonti.

3. **Gameplay Hook**
   - Ganciare `tracks/sensience_stages.yaml` al sistema di progressione (reinforce neurale, feats evolutive, crescita clan).

4. **QA**
   - Marcate `[VERIFY]` tutto ciò che viene dal ricordo mnemonico; sostituirlo solo dopo scraping manuale/validazione.

5. **Roadmap**
   - v0.2: popolamento `evolution_tree.yaml` e `neuronal_nodes.yaml` da fonti confermate.
   - v0.3: tuning numerico (group size, planning, bonus) + test automated (`scripts/auto_eval_from_yaml.py` se presente).
