
# Piano Fonti — *Ancestors: The Humankind Odyssey*

> Navigazione non eseguita. Questo è un **blueprint** operativo per raccogliere le fonti in modo completo e tracciabile.

## Priorità 1 — Documentazione diretta di gioco
- **Manuale / Codex in‑game**: schermate (screenshot), categorie **Neuronale**, **Mutazioni genetiche**, **Evoluzioni**, **Clan** (cure, legami, nascite), **Territorio**, **Cacciatori/Predatori**, **Raccolta/Tool**.
- **Menu “Neuronal”**: albero per **Sensi / Motricità / Intelligenza / Comunicazione** (nomi da verificare con lo UI in italiano/inglese).
- **Schermate Evoluzione**: requisiti per i **salti evolutivi** (feats, nascite, tempo trascorso, rinforzi neurali).

## Priorità 2 — Siti ufficiali e knowledge base
- **Panache Digital Games** — sito ufficiale (news, FAQ).
- **Private Division** — publisher info, patch notes (versioni e fix che influenzano meccaniche).
- **PCGamingWiki** — sezione “Game mechanics” e settings che impattano input/sensibilità.

## Priorità 3 — Wiki e Guide strutturate
- **Ancestors Wiki (Fandom)**: sezioni *Evolution*, *Neurons/Neuronal*, *Mutations*, *Feats*, *Species/Lineage*, *Tools*, *Clan Mechanics*. Estrarre tabelle complete.
- **IGN / GameFAQs / PowerPyx / TrueAchievements** (o equivalenti) per “all evolutions”, “complete neuron trees” (confronto incrociato fra almeno 2 fonti).
- **Steam Community Guides**: “Complete Evolution Guide”, “All Mutations & Neurons”, “How to reach [Species]” — selezionare 2–3 guide ad alta reputazione.

## Priorità 4 — Discussioni e validazione
- **Reddit r/ancestors**: megathread di guide, Q&A su condizioni non ovvie (es. mutazioni rare, rinforzi, comportamenti del clan).
- **YouTube (longform guide)**: una guida enciclopedica con capitoli/timestamp per doppio check dei requisiti.

## Metadati per ogni fonte da registrare nel DB
- `source_id`, `type` (official/wiki/guide/reddit/video), `title`, `url`, `author`, `date`, `last_checked`, `coverage` (neuronal/evolution/feats/mutations/tools/clan), `confidence` (1–5), `notes`.
