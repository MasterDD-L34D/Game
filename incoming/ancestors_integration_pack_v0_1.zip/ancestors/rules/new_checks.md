
# Nuove Prove (Checks) — Estensioni

## Equilibrio (Dex)
- Camminare su appigli stretti, evitare ribaltamento, mantenere postura.
- Interazioni: morfologie alle gambe, terreno, vento, carico.

## Interocezione (Con)
- Ascolto degli stati interni: gestione dolore, respiro, ritmi.
- Interazioni: nocicezione/termocezione/propriocezione; recupero dallo shock/panico.

> CD base 12; vantaggi/svantaggi come da `rules/checks.md`.
