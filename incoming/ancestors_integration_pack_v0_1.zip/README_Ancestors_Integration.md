
# Ancestors — Integration Pack (v0.1, 2025-10-28)

Questo pacchetto prepara l'integrazione **senza dipendenze web** dei dati e delle logiche di *Ancestors: The Humankind Odyssey* all'interno dell'ecosistema **Evo Tactics**.

> Nota: la raccolta **fonti** non è stata eseguita online (navigazione disattivata). Qui trovi un **piano di raccolta** accurato e schemi dati completi per importare il materiale quando sarà possibile.

## Obiettivi
- Strutturare **alberi evolutivi** e **neuroni/capacità** in file YAML/CSV coerenti con il repo.
- Introdurre il **tratto Sensienti** con **stadi T1–T7** (scala di socialità/cognizione/cultura).
- Aggiungere **sistemi interocettivi** (propriocezione, equilibrio, nocicezione, termocezione, interoception awareness).
- Fornire una **mappatura** immediata con tipi già presenti nel repo (*morph: senses, metabolism, offense/defense, rules/checks…*).

## Struttura
```
ancestors/
  sources_plan.md
  schema/
    evolution_tree.yaml
    neuronal_nodes.yaml
    feats.csv
  tracks/
    sensience_stages.yaml
  evo_traits/
    interoception_traits.yaml
    sensience_tags.yaml
  mapping/
    evo_tactics_mapping.yaml
  rules/
    new_checks.md
  HOW_TO_IMPORT.md
```
