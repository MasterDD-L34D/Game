# Ancestors Integration Pack — v0.5 (2025-10-29)

Questa versione amplia **neurons_all.csv** multi-ramo con 62 voci verificate o parzialmente verificate.
- Completato **Omnivore (11/11)** con trigger/effect confermati.
- Aggiunti **18+ nodi Senses** con descrizioni ufficiali.
- Aggiunti nodi chiave **Dexterity** (es. Applied Force, Carrying Ability, True Aim, True Grip, ecc.).
- Aggiunti nodi **Communication** (Kinesics, Body Language, Social Confidence, Imitation).
- Inseriti **20** nodi Motricity (nomi verificati via icone) con TODO su trigger/effect.

Controlla `neurons_QA_todo.csv` per lo stato di completamento contro il target ramo (297 totale).
Ogni riga include `source_url` per la tracciabilità e la futura rifinitura.
