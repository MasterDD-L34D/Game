# EvoTactics Developer Kit
Base DevKit per drift-check, YAML e telemetria.
