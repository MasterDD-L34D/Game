#!/bin/bash
echo 'Installer running — simulated setup.'
