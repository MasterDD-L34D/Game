# stub validator — vedi versione completa proposta in precedenza
