// stub drift check
