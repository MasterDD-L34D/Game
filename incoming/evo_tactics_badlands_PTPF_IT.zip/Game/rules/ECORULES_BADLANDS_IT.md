# Requisiti soddisfatti — vedere badlands.yaml: compliance
