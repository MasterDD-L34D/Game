# Pacchetto Minimo — Evo Tactics (v5, 2025-10-24)

### Nuovo in v5
- **MBTI Gates (soft)**: `form/mbti_gates.yaml` con soglie e penalità di primo turno.
- **Schemas JSON**: `schemas/pg.schema.json`, `schemas/npg.schema.json` per convalide automatiche.
- **Spawn Pack VTT**: `exports/spawn_packs/pack_biome_jobs_v1.json` con **12 NPG** pronti.
- **Quickstart GM**: `GM_Quickstart.md` (setup → telemetria → ricompense → validazione).

Tutto integrato con contenuti delle versioni precedenti (specie/morph/biomi/jobs/traits/gear/rules/social/telemetry).

### Prossimi step suggeriti
- Aggiungere *stance* e *guardie* come moduli (`rules/stances.yaml`).
- Estendere `tags/weapon*.yaml` con 3–5 tag addizionali (Es.: *Vibrante*, *Ariosa*, *Cinetica*).
- Spawn Pack v2 con **varianti di rank** (R2) e **elite/boss**.


## Patch v6 — placeholder 'playtest-needed' (2025-10-24)
- **Skirmisher**: aggiunta abilità `feint_step` (coerente con `pi_costs`).
- **Regole**: `rules/proficiency.md`, `rules/checks.md`, `rules/stances.yaml`, `rules/units_grid.md`, `rules/mating_biome_links.md`, `rules/tuning.md`.
- **Surge**: `surge/overdrive.yaml` (consumo **SG**).
- **Tag avanzati**: `tags/weapon_advanced.yaml`.


## Release v7 — integrazione completa Enneagramma (2025-10-24)
- Integrato l'**add-on Enneagramma** sotto `modules/personality/enneagram/`.
- Estesi i **temi 1..9** in `ennea/themes.yaml` e hooks relativi in `personality_module.v1.json`.
- Aggiunto **validator** `tools/validate_v7.py` per verificare la copertura dei temi e gli alias.
- Quickstart aggiornato con sezione dedicata ai temi.


## Release v8 — profilo alternativo & spawn pack (2025-10-24)
- Aggiunta **mappa ruoli→temi alternativa** (`modules/personality/enneagram/role_theme_mappings.yaml`).
- File selettore profilo: `role_theme_profile.yaml` (attuale: `alt`).
- Generato **Spawn Pack v8 (alt)**: `exports/spawn_packs/pack_biome_jobs_v8_alt.json`.
