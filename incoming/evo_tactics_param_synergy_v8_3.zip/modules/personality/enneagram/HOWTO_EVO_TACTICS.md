# HOWTO — Integrare Enneagramma in Evo Tactics v6 (beta)

1) Copia `modules/personality/enneagram/` nel tuo pacchetto.
2) Aggiungi a Scheda PG il blocco `personality.enneagram` (vedi `pg_enneagram_template.yaml`).
3) Carica `personality_module.v1.json` e `compat_map.json` nel tuo orchestratore.
4) Collega il tuo event bus a `hook_bindings.ts` e usa `emitAlias()` con gli eventi italiani o canonici.
5) Verifica che i nomi STAT del tuo engine coincidano con gli alias in `compat_map.json` (es. `ac`, `parry`, `pp`, `pe`, `sg`).

## Temi del progetto (7/3)
- **Explorer (7)** → evento `scoperta_area` / `on_new_area_discovered` → +1 **PE** (1/incontro).
- **Conqueror (3)** → evento `colpo_decisivo` / `on_finisher_hit` → +1 **PP** (1/incontro).

## Limiti & stacking (riassunto)
- Famiglie esclusive: `core_emotion`, `hornevian`, `harmonic`, `object_rel` (vedi modulo).
- Passive istintive SP/SO/SX non si sommano; lo **stacking** (es. `sx/so`) sostituisce la base SX con bonus diverso.

> Stato: **beta**. Parametri conservativi: +5% / +2 flat / durata 1 turno. Rifinire dopo playtest.
