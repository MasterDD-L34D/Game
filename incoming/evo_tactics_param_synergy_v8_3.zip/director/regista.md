# Regista — Generazione NPG per Bioma & Comportamento

**Funzione:** creare NPG dinamici in base al bioma, alla mappa e alla telemetria del party.

## Pipeline
1. **Bioma** (vedi `biomes/starter_biomes.yaml` + tabelle estese)
2. **Archetipo Job** (vanguard/skirmisher/warden/artificer/invoker/harvester)
3. **Forma/Tratti** (match con PF_session e assi MBTI)
4. **Agenda**: ostile, neutrale, alleabile, curioso, predatorio
5. **Ganci Sociali**: preferenze Piace/Non Piace, potenziale Recruit/Mating

## Output NPG (minimo)
- `species`, `morph_budget`, `job` (1–2 unlock), `traits (1–2)`, `gear` basilare
- **Comportamento**: tabella *se vede il party → reazione*, *se viene ferito → piano*, *se in inferiorità → fuga/alleanza*

## Punti Evolutivi
- L'interazione (sociale, combattimento, esplorazione) produce **PI/PE/seed** secondo `rules/economy.md`.
