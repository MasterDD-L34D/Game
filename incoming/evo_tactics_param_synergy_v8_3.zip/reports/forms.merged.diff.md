--- base
+++ merged
@@ -1,7 +1,7 @@
 meta:
   file: forms.yaml
-  version: '0.1'
-  description: Forme Base (16) con innate e pacchetti PI.
+  version: '0.2'
+  description: Forme Base (16) con innate e pacchetti PI. (merged semantic union)
   last_updated: '2025-10-24'
 global:
   starting_pi_points: 7
