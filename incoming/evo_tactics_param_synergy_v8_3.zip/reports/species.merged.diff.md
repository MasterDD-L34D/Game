--- base
+++ merged
@@ -1,7 +1,8 @@
 meta:
   file: species.yaml
-  version: '0.3'
-  description: Catalogo Specie & Parti morfologiche per Evo Tactics (TV/d20).
+  version: '0.4'
+  description: Catalogo Specie & Parti morfologiche per Evo Tactics (TV/d20). (merged
+    semantic union)
   last_updated: '2025-10-24'
 global_rules:
   morph_budget:
@@ -109,3 +110,13 @@
     metabolism: burst_anaerobic
   synergy_hints:
   - echo_backstab
+  alternates:
+    incoming_dune_stalker:
+      file: species/dune_stalker.yaml
+- id: sand_burrower
+  file: species/sand_burrower.yaml
+- id: echo_wing
+  file: species/echo_wing.yaml
+- id: rust_scavenger
+  file: species/rust_scavenger.yaml
+schema_reference: {}
