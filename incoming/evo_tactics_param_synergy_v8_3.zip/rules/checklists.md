# Checklist Missione

## Pre-Missione
- Scegli Bioma (vedi `biomes/*.yaml`)
- Verifica Nest se serve (recruit/mating)
- Alloca PI/PP/SG secondo economia

## Durante la Missione
- Applica *hazards* e *modifiers* del bioma
- Usa tabelle comportamento Regista per NPG
- Aggiorna Telemetry (fine turno/scene)

## Debrief
- Applica ricompense (PE/PI/seeds)
- Proietta `PF_session` su `form.axes`
- Effettua respec/graft se usi seed
