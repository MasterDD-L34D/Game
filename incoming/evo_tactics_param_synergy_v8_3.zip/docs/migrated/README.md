# Evo Tactics — TV/d20 (Design + Data)
Vedi `docs/00-INDEX.md` per l'indice. Validator: `tools/py/*` o `tools/ts/*`.
