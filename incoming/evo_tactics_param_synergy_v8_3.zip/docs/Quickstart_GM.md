# Quickstart GM — Evo Tactics (v5, 2025-10-24)

## Setup istantaneo
1. Scegli il **Bioma** (Desert / Cavern / Badlands).
2. Tira l'incontro in `director/encounter_tables.yaml` oppure estraine uno pronto:
   ```bash
   python scripts/spawn_npg.py desert
   ```
3. Applica hazard/modifier del bioma e aggiorna **Telemetry** a fine turno/scene.
4. A fine incontro, assegna ricompense con `director/regista_rewards.yaml`.

## Riferimenti rapidi
- **Risorse**: PT (azioni), PP (potenza/Surge), PI (sblocchi), PE (progressi), SG (carica 0..3).
- **Formule**: vedi `rules/stats.md` (HP/AC/Parry/Guardia/Move/Vel).
- **Sinergie**: `rules/synergies.yaml` (echolocate+flank_mastery | echolocate+backstab).
- **Gates Job**: `rules/job_gates.yaml` (soft, +1 PI se forzi).
- **Mating/Recruit**: `social/mating.md` + `nest/requirements.yaml` + `social/affinity_trust.md`.

## One-Pager NPG disponibili
- Desert: Skirmisher, Vanguard
- Cavern: Warden, Invoker
- Badlands: Artificer, Harvester

> Pro-tip: impagina i one-pager in 1 pagina ciascuno per stampa tascabile.
