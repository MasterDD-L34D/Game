# Loop di Gioco (alto livello)

Metagioco (epoche/stagioni) → draft/creazione specie → **Match TBT** (obiettivi)
→ telemetria VC → **mutazioni / rami sbloccati** → raffinamento build → matchmaking.

Modalità: co-op vs Sistema (Director), 1v1/2v2/4v4, raid PvE, asincrono a corrispondenza.
