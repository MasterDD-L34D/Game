# Telemetria → Vettore Comportamentale (VC)

Eventi: hit/miss/crit/heal/buff/debuff/objective_tick/tile_enter/LOS_gain/formation_time/chat_ping/surrender/tilt triggers/turn_time.
Finestre: per-turno, per-fase, per-mappa (EMA + clipping).

Indici: Aggro, Risk, Cohesion, Setup, Explore, Tilt → layer MBTI-like + Ennea-like (solo gameplay).
