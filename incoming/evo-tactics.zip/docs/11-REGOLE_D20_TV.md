# Adattamento TV/d20

- **Schermo condiviso** (app/sito TV): stato gruppo, mappa, log VC, suggerimenti sblocchi.
- **Dadi**: d20 centrale; dadi “Descent-like” mappati su spese PT/PP (icone/pattern).
- **Condivisione tavolo**: ogni turno produce **eventi grezzi** per VC (no quiz).
- **Privacy**: toggle “profilazione stile” (on/off); reset profilo (amnesia evolutiva).
