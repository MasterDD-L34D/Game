# Pilastri di Design (sintesi)

1. **Tattica leggibile** (FFT-like): iniziativa, posizionamento, altezze, facing, reazioni.
2. **Evoluzione emergente** (Spore-like): tratti/morfologie/job sbloccati da comportamenti.
3. **Identità doppia**: Specie × Job → sinergie/counter chiari.
4. **Temperamenti giocati**: VC → MBTI-like + Ennea-like (telemetria ludica).
5. **Fairness**: budget morfo, cap sugli stack, counter espliciti, MMR per stile/build.
