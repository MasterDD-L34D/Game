# Visione

“Tattica profonda a turni in cui **come giochi** modella **ciò che diventi**.”
