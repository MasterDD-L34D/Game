# Regole di Sblocco + Economia PE

- **PE** dal delta VC (non solo vittoria).
- 12 regole base (Ambusher, Pathfinder, Caregiver, Gambler, Stoic, Architect, …).
- **Fairness**: diminishing returns; ogni tratto forte ha counter esplicito.
