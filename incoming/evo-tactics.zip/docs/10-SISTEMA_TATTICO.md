# Sistema Tattico (TV/d20)

- **Iniziativa**: CT a scatti; VEL può concedere riprese extra.
- **Economia azioni**: 2 AP (move/azione) + **Reazioni** (parry/counter/overwatch).
- **MoS**: ogni +5 sulla DC = +1 step danno; a 5/10 si guadagna PP bonus.
- **Terreno/Altezze/Facing**: backstab, coperture, LoS chiara.
- **Status**: fisici (Sanguinamento, Frattura, Disorientamento) e mentali (Furia, Panico).
- **PT**: +1 su 15–19 naturale, +2 su 20 naturale, +1 ogni +5 MoS; spese: perforazione/spinta/condizioni/combo.
- **Guardia & Parata**: Guardia (mitigazione cumulativa); Parata `d20` reattiva riduce 1 step e genera PT difensivi.
