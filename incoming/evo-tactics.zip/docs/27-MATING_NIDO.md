# Mating / Nido

- **Attrazione/Convincimento**: tabelle “Piace/Non piace” specie/job; azioni sociali cambiano atteggiamento.
- **Reclutamento**: ex-nemici → alleati; riproduzione richiede **covo** conforme (`env/structure/security/resources/privacy`).
- **Riproduzione**: no sesso binario; accoppi con chiunque (anche NPG Director).
- **Ereditarietà**: slot/parti pesati; bias `form_seed_bias`; mutazioni (affissi bioma).
