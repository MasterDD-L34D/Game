# UI TV — Carta Temperamentale & Albero Evolutivo

- 4 assi MBTI-like + 3 temi Ennea-like; effetti **solo gameplay**.
- Albero Evolutivo reattivo; nodi pulsano quando “meriti” lo sblocco.
- Registro Evoluzione: feed eventi → tratti ottenuti.
- Blocco salvataggio se over-budget; warning ≥90%; mostra sinergie attive e counter noti.
