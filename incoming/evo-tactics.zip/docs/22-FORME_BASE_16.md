# Forme Base (16) — seed temperamentale

Ogni Forma assegna: 1 **innata** + **7 PI** (pacchetti preconfezionati). VC in-match sposta gradualmente i pesi (non è un test psicologico).

La tabella sintetica è nel Design Doc; i pacchetti PI completi sono in `data/forms.yaml`.
