# Roadmap (MVP → Alpha)

- Core TBT, 6 Specie base, 6 Job base, Telemetria VC, 12 Regole Sblocco, UI identità.
- 2 Mappe (caverna/savana), Matchmaking, Privacy/Reset.
- 50 partite playtest con audit predator/counter.
