# NPG, Biomi, Affissi & Director

- **Director**: genera NPG via `spawn_profile` (power_range, group_size, role_weights).
- **Biomi**: mood/diff_base_mod; affix_bias (sand_wind, crystalline, dense_spores, …).
- **UI**: surfacing dei counter noti vs specie/parti correnti.
