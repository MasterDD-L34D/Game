# neurons_*.csv schema (v1.0)

Columns:
- `branch`: High-level branch (e.g., Senses, Ambulation)
- `code`: Game code if known (e.g., SO 01, SS 04, AB 07). Leave blank if unknown.
- `name`: Neuron name from the game/wiki.
- `type`: `regular` | `mutation` (genetic)
- `unlock_trigger`: Short hint for how you unlock/mature it (action or context).
- `effect_short`: One‑line effect summary (what changes in gameplay).
- `connects_from`: Comma‑separated prerequisite codes/nodes if known.
- `connects_to`: Comma‑separated forward links if known.
- `sources`: Semicolon‑separated human‑readable sources/slugs.
