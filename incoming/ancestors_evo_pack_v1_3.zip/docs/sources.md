# Sources (seed, to verify in-game wording)
- Ancestors Wiki — Neurons (branch taxonomy, counts)
- Ancestors Wiki — Senses (neuronal branch), Hearing, Identify, Memorize
- Ancestors Wiki — Dexterity (neuronal branch) (DE→AB cross‑links)
- Ancestors Wiki — Endurance (AB 01); Movement Endurance (AB 02–03); Climb Endurance (AB 04, AB 06); Carrying Endurance (AB 07–09); Pain Endurance (AB 11)
- Ancestors Wiki — Meteorite Site; Category:Meteorite sites
- Reddit threads (meteorite locations & respawn behavior confirmation)
