# Ancestors — Neuronal Data v0.3 (Evo Tactics)

This package includes:
- `data/neuronal_branch_counts.csv` — official per-branch counts (regular vs genetic).
- `data/combat_neurons_subset.csv` — curated list of combat-related neurons with short effects and unlock hints.
- `traits/traits_sensory_extended.yaml` — extended sensory trait ladder (Thermo-, Nocio-, Proprio-, Equilibrio-, Interocezione) + sentience tiers T0–T5.
- `docs/SOURCES.md` — links to the primary sources used.

> Scope note: Ambulation full dump (26 neurons) and other branches will be appended in `v0.4+` once verified line-by-line against the map images and branch pages.
