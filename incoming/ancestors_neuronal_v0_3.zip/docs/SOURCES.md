Primary game wiki (branch totals, lists and mechanics):
- Ancestors Fandom — Neurons and Neuronal branches (counts, structure)
- Ancestors Fandom — Senses (list table with codes and descriptions)
- Ancestors Fandom — Dexterity, Intelligence (branch pages with list tables)
- Ancestors Fandom — Combat (global neurons impacting combat list)
- Ancestors Fandom — Category: Neuronal Branches Maps (full/detailed map PNGs for each branch)
- Ancestors Fandom — Stand Up (Motricity WA codes, balance)
- Ancestors Fandom — Meteorite, Meteorite Site, Genetic Mutations (mechanics)

Supplementary guides:
- ProdigyGamers — Meteorite uses and locations; precious stones triggering meteorites

Background physiology for extended senses:
- Encyclopaedia Britannica — Thermoreception, Nociception, Proprioception; Human sensory reception: Vestibular sense; Ear: physiology of balance

Anthroposophy reference (for "corpo senziente"):
- Italian resources summarizing Steiner’s “corpo senziente / corpo astrale”