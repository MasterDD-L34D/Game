# Sistema Prove & CD (playtest-needed)

## Test base
- **Tiro**: 1d20 + mod stat + bonus (circostanza/competenza).
- **CD**: 10 facile, 12 moderato, 15 difficile, 18 molto difficile (linea guida).
- **Vantaggio/Svantaggio**: tira due d20, tieni il migliore/peggiore.

## Tipi di prove
- **Finta (Feint)**: 1d20 + mod Car o Des (scegli) vs **Percezione** o **Disciplina** del bersaglio (playtest-needed).
- **Atletica**: salti/corse/spinte.
- **Stealth/Percezione**: introduci svantaggi/bonus da bioma e sensi (echolocate, mag_sense).

## Tiri Salvezza (TS)
- **Tempra (Con)**, **Riflessi (Des)**, **Volontà (Sag)** — CD tipica 12 (varia con livello minacce).
