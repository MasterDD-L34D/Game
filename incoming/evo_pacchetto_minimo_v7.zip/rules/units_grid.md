# Unità & Griglia (playtest-needed)

- **1 casella = 1,5 m** (standard tattico).
- **Raggio/Linea/Cono**: misura per caselle intere; arrotonda per difetto.
- **Movimento diagonale**: alterna 1/2/1/2… (oppure 1/1/1… per semplicità, scegli al tavolo).
- **Conversione**: dove è indicato in metri, fornisci anche caselle tra parentesi.
