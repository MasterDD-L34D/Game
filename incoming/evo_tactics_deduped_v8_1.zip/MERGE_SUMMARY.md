# Merge Summary — Evo Tactics (v8 + user ZIP)
Date: 2025-10-24

## Inputs
- v8 package dir: /mnt/data/evo_pacchetto_minimo
- user zip: evo-tactics-final (1).zip (root detected: (none))

## Results
- Output zip: evo_tactics_merged_final.zip
- Files from v8: 103
- Files added from user zip (no conflict): 117
- Conflicts (kept v8; user's copy stored under `archive_from_user/`): 1
- Extra docs added: 3

### First 20 user files added (no conflict)
- NORMALIZE_REPORT.json
- docs/00-INDEX.md
- docs/01-VISIONE.md
- docs/migrated/GM_Quickstart.md
- docs/migrated/MERGE_REPORT.md
- docs/migrated/README.md
- docs/migrated/README_MIN_PACCHETTO.md
- docs/migrated/behavior_tables.md
- docs/migrated/regista.md
- docs/migrated/HOWTO_EVO_TACTICS.md
- docs/migrated/README_ADDON_PER_PACCHETTO.md
- docs/migrated/README_ENNEAGRAMMA.md
- docs/migrated/README_INTEGRAZIONE_MECCANICHE.md
- docs/migrated/checklists.md
- docs/migrated/checks.md
- docs/migrated/economy.md
- docs/migrated/preferences_tables.md
- docs/migrated/privacy.md
- docs/migrated/proficiency.md
- docs/migrated/resources.md

### First 20 conflicts (user version preserved under archive_from_user/)
- docs/Quickstart_GM.md

