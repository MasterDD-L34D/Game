
# Dati Ancestors (Stub) — v0.2 (2025-10-29)

Questi CSV **NON** sono ufficiali: contengono etichette e requisiti generici marcati **[VERIFY]**.
Appena possibile, sostituisci i campi con i nomi e le condizioni reali presi da:
- UI in-game (Neuronal tree, Evolution milestones)
- Wiki Fandom / Steam Guides autorevoli
- Patch notes ufficiali

File:
- `neuronal_nodes_glossary.csv`
- `evolution_tree.csv`
