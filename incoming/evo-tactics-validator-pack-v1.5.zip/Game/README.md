# Evo-Tactics · Validator Pack v1.5

Build: 2025-10-25

Contiene config, validator e schemi aggiornati. Vedi cartella Game/tools/py per gli script.
