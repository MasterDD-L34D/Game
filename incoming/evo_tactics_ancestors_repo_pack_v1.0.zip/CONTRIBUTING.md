# Contributing

- Aggiungi voci a `data/neurons_all.csv` seguendo lo schema e usando `source_url` puntato alla pagina wiki specifica.
- Mantieni i codici neurone esatti (es. `DE_06`, `BB_AL_01`, suffissi `-2/-3` quando presenti).
- Esegui `python3 scripts/validate_dataset.py` prima di aprire una PR.
- Per i branch con conteggi sconosciuti (Settlement, Metabolism), invia prima un'issue per definire i totals.
