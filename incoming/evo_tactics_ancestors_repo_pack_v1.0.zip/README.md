# Evo Tactics — Ancestors Integration Pack (v1.0)

**Data pack pronto per il repo**: albero evolutivo, rami neurali, neuroni (dump parziale con fonti), meteore/mutazioni,
feat d'evoluzione e layer **Sensienti**.

## Struttura
```
.
├── data/
│   ├── evolution_milestones.csv
│   ├── neuronal_branches_catalog.csv
│   ├── neurons_all.csv
│   ├── meteorite_sites.csv
│   ├── genetic_mutations_summary.csv
│   └── evolution_feats_examples.csv
├── sensienti/
│   ├── sensienti_traits.yaml
│   └── sensienti_trait_to_neurons.csv
├── schema/
│   ├── neurons_all.schema.json
│   └── sensienti_traits.schema.json
├── scripts/
│   └── validate_dataset.py
└── docs/
    ├── validation_report.md (generato dallo script)
    └── CITATIONS.md
```

## Come validare
```bash
python3 scripts/validate_dataset.py
```

## Copertura attuale
- **Neuroni estratti**: sottoinsieme completo per **Omnivore (11/11)**, completo per **Attack (8/8)**, **Dodge (10/10)**, **Self-Control (12/12)**;
  subset ricco per **Senses** e **Dexterity**, avvio **Ambulation** (catena Carrying Endurance).
- **Target finale**: 297 neuroni (208 regular + 89 mutazioni) — branch counts nel file `data/neuronal_branches_catalog.csv`.
- Ogni riga ha `source_url` per tracciabilità.

## Layer 'Sensienti'
File `sensienti/sensienti_traits.yaml` e mapping in `sensienti/sensienti_trait_to_neurons.csv`: definiscono i tier T1–T6
e i collegamenti ai neuroni (con placeholder da rifinire su Intelligence/Settlement).

## Licenza
MIT (vedi LICENSE)
