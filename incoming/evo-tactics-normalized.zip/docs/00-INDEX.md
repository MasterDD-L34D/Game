# Indice

- Visione
- Pilastri
- Loop


## Documenti migrati
- `docs/migrated/GM_Quickstart.md`
- `docs/migrated/HOWTO_EVO_TACTICS.md`
- `docs/migrated/MERGE_REPORT.md`
- `docs/migrated/README.md`
- `docs/migrated/README_ADDON_PER_PACCHETTO.md`
- `docs/migrated/README_ENNEAGRAMMA.md`
- `docs/migrated/README_INTEGRAZIONE_MECCANICHE.md`
- `docs/migrated/README_MIN_PACCHETTO.md`
- `docs/migrated/affinity_trust.md`
- `docs/migrated/behavior_tables.md`
- `docs/migrated/checklists.md`
- `docs/migrated/checks.md`
- `docs/migrated/economy.md`
- `docs/migrated/preferences_tables.md`
- `docs/migrated/privacy.md`
- `docs/migrated/proficiency.md`
- `docs/migrated/regista.md`
- `docs/migrated/resources.md`
- `docs/migrated/stats.md`
- `docs/migrated/tuning.md`
- `docs/migrated/units_grid.md`
- `docs/migrated/validation.md`
