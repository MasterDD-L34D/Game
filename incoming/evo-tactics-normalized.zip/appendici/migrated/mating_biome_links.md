# Collegamenti Bioma ↔ Nest/Mating (playtest-needed)

- **Desert**: richiede riparo doppio (tenda + frangivento) per Nest OK.
- **Cavern**: temperatura/stabilità: verifica crolli (CD 12) prima di Mating.
- **Badlands**: servono 2 unità di risorse metalliche per nido sicuro (vedi `nest/requirements.yaml`).
- **Bonus di contesto**: se il bioma è *preferito* dalla specie partner, Affinity +1 al check iniziale.
