# Pacchetto Minimo — Evo Tactics (Bozza 2025-10-24)

Questa versione integra elementi emersi nelle conversazioni del progetto:

- **Jobs estesi**: vanguard, warden, artificer, invoker, harvester (stub completi di attive/passive/ultimate).
- **Trait di progetto**: Focus Frazionato (T1), Backstab (T1) — per mantenere la sinergia con *echolocate*.
- **Mating System** ispirato alle tue note (MBTI/Enneagramma, Piace/Non Piace, Recruit, Nest). 
- **Regista**: pipeline per NPG generati da bioma, con comportamenti e ricompense evolutive.
- **Economy**: PE→PI, Seeds, PP/SG; tabelle Piace/Non Piace; Privacy & Reset.

Per integrare il tuo PG **Klynn**, puoi mantenere la sinergia `echolocate+backstab` oppure `echolocate+flank_mastery` (non cumulano).

## TODO suggeriti
- Ampliare `biomes/*` con tabelle Piace/Non Piace specifiche per 3–5 specie.
- Bilanciare CD/percentuali con playtest.
- Aggiungere schede per armi, tag e surge aggiuntive (es.: arma *ranged* per Invoker).
