# Regole Statistiche (provvisorie)

**Obiettivo:** validare i valori di esempio (HP 13, AC 13, Parry +2, Guardia 0, Move 5, Vel +1).

## Punteggi & Mod
Le statistiche (Str, Dex, Con, Int, Wis, Cha) sono già espresse come **mod** (es.: Dex +2).

## HP
Formula specie Dune Stalker:  
`HP = hp_base (10) + (CON_mod * 3) + hp_from_morph + hp_from_job`  
Per Klynn: `10 + (1*3) + 0 + 0 = 13` ✅

## AC (Classe Armatura)
`AC = 10 + Dex_mod + armor_bonus + morph_bonus + gear_bonus`  
- Elastomer Skin: `morph_bonus +1`  
Per Klynn: `10 + 2 + 0 + 1 + 0 = 13` ✅

## Parry
`Parry = Dex_mod` **se** impugni arma con tag *Tecnico* o *Leggera* e non usi scudi.  
Per Klynn e Twin Blades (Tecnico): `Parry = +2` ✅

## Guardia
Rappresenta copertura/stance difensiva.  
`Guardia = 0` di base se non assumi una Guardia e non usi scudi. ✅

## Move & Vel
- `Move` è la distanza base per **Camminare**: specie Dune Stalker = 5 caselle.  
- `Vel` è un modificatore di **Sprint** o azioni di scatto.  
  - Burst Anaerobic: `+1 Vel` durante lo sprint (vedi morph). ✅
