# Pacchetto Minimo — Evo Tactics (Bozza 2025-10-24)

Contiene i reference minimi per la scheda PG di esempio (Klynn). Struttura cartelle e file YAML/MD
per specie, morph, forme, job, regole base, armi/tag/surge, biomi, social/nest e telemetria.

## Micro-fix inclusi
- Sinergia consigliata: `echolocate+flank_mastery:+5%` (vedi `rules/synergies.yaml`).
- Aggiunto `morph_budget_max: 12` (vedi `species/dune_stalker.yaml`).
- Formule provvisorie in `rules/stats.md` per validare 13/13/+2/0/5/+1.
- Definiti **PP** e **SG** in `rules/resources.md`.

## Prossimi passi
- Playtest percentuali/flanking.
- Espandere cataloghi tag/surge e biomi.
- Integrare scaling per livelli/stage.
