# Evo-Tactics — BADLANDS Ecosystem Package (IT)

**Contenuto**
- `Game/data/biomes/badlands.yaml` — bioma in formato PTPF con rules/compliance.
- `Game/data/foodwebs/badlands_foodweb.yaml` — foodweb con nodi/archi e trigger di cascata.
- `data/species.yaml` — snapshot specie condiviso in chat.
- `tools/yaml_validator.py` — valida coperture & minimi (sentient/apex/keystone/threat/event/ponte).
- `docs/ECORULES_BADLANDS_IT.md` — regole in prosa.
- `docs/IDEA_CATALOG_BADLANDS_IT.md` — riassunto per Google Doc.

**Uso rapido**
```bash
python3 tools/yaml_validator.py --root Game/data
```

**Ultimo aggiornamento**: 2025-10-25
