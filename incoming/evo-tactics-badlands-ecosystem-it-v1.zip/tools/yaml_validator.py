#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import sys
import argparse
from pathlib import Path
from typing import Dict, Any, List

try:
    from ruamel.yaml import YAML
except Exception:
    print('[WARN] ruamel.yaml non disponibile, uso yaml standard')
    import yaml as _pyyaml
    class YAML:
        def __init__(self):
            pass
        def load(self, stream):
            return _pyyaml.safe_load(stream)

YAML_EXTS = ('.yml', '.yaml')
REQUIRED_BIOME_FIELDS = ['biome_id','label','abiotic','hazards','preferences','modifiers','trophic_levels','functional_groups','ecosystem_rules','compliance']
FUNC_KEYS = ['predatori','prede','erbivori','impollinatori','dispersori','simbionti','commensali','parassiti_parasitoidi','detritivori','decompositori','filtratori','ingegneri_ecosistema','specie_chiave','ombrello_indicatori','invasive_alloctone','minaccia','evento','ponte']
RULE_KEYS = ['require_full_functional_coverage','require_sentient_min','require_apex_min','require_keystone_min','require_threat_min','require_event_min','require_bridge_min']

class ValidationError(Exception):
    pass

class BiomeReport:
    def __init__(self, path: Path):
        self.path = path
        self.errors: List[str] = []
        self.warnings: List[str] = []
        self.info: List[str] = []
    def add(self, level: str, msg: str):
        getattr(self, f"{level}s").append(msg)
    def ok(self) -> bool:
        return not self.errors
    def to_text(self) -> str:
        out = [f"Report: {self.path}"]
        if self.errors:
            out.append('\nERRORS:')
            out += [f"- {e}" for e in self.errors]
        if self.warnings:
            out.append('\nWARNINGS:')
            out += [f"- {w}" for w in self.warnings]
        if self.info:
            out.append('\nINFO:')
            out += [f"- {i}" for i in self.info]
        return '\n'.join(out)

def load_yaml(path: Path) -> Dict[str, Any]:
    yaml = YAML()
    with path.open('r', encoding='utf-8') as f:
        data = yaml.load(f)
    if not isinstance(data, dict):
        raise ValidationError('Documento YAML non è un mapping di primo livello')
    return data

def validate_biome(doc: Dict[str,Any], rep: BiomeReport):
    for k in REQUIRED_BIOME_FIELDS:
        if k not in doc:
            rep.add('error', f"Campo richiesto mancante: {k}")
    if 'functional_groups' in doc:
        fg = doc['functional_groups'] or {}
        missing = [k for k in FUNC_KEYS if k not in fg]
        if missing:
            rep.add('error', f"Gruppi funzionali mancanti: {missing}")
        else:
            empty = [k for k in FUNC_KEYS if not fg.get(k)]
            if empty:
                rep.add('error', f"Gruppi presenti ma vuoti: {empty}")
    rules = doc.get('ecosystem_rules', {})
    for k in RULE_KEYS:
        if k not in rules:
            rep.add('error', f"Regola mancante: {k}")
    compl = doc.get('compliance', {})
    def count_in(group):
        return len(doc.get('functional_groups', {}).get(group, []) or [])
    if rules.get('require_full_functional_coverage'):
        for key in FUNC_KEYS:
            if count_in(key) == 0:
                rep.add('error', f"Copertura funzionale non rispettata: {key} vuoto")
    reqs = [('require_keystone_min','specie_chiave','keystone_count'),
            ('require_threat_min','minaccia','threat_count'),
            ('require_event_min','evento','event_count'),
            ('require_bridge_min','ponte','bridge_count')]
    for rule_key, group_key, comp_key in reqs:
        val = rules.get(rule_key, 0)
        if isinstance(val, bool):
            val = 1 if val else 0
        if count_in(group_key) < max(1, int(val)):
            rep.add('error', f"Regola {rule_key} non soddisfatta: {group_key} < {val}")
        reported = compl.get(comp_key)
        if reported is not None and reported != count_in(group_key):
            rep.add('warning', f"Compliance {comp_key} riporta {reported} ma calcolo è {count_in(group_key)}")

    # apex & sentient placeholder (nomi provvisori)
    apex_calc = count_in('predatori') + count_in('specie_chiave')
    sentient_calc = 0
    for bucket in doc.get('functional_groups', {}).values():
        for sp in bucket or []:
            if isinstance(sp, str) and sp in ('cantore_polvere','regina_vesparia_ferroemato','corvo_ferromag','mirmec_ferro'):
                sentient_calc += 1
    if compl.get('apex_count') and compl['apex_count'] < 1 and apex_calc >= 1:
        rep.add('warning', 'apex_count in compliance sembra sottostimato')
    if compl.get('sentient_count') and compl['sentient_count'] < 1 and sentient_calc >= 1:
        rep.add('warning', 'sentient_count in compliance sembra sottostimato')

def scan_folder(root: Path) -> List[BiomeReport]:
    reports: List[BiomeReport] = []
    for path in root.rglob('*'):
        if path.suffix.lower() in YAML_EXTS and path.name.endswith('badlands.yaml'):
            rep = BiomeReport(path)
            try:
                doc = load_yaml(path)
                validate_biome(doc, rep)
                if rep.ok():
                    rep.add('info', 'OK - biome valido e conforme alle regole')
            except Exception as e:
                rep.add('error', f"{type(e).__name__}: {e}")
            reports.append(rep)
    return reports

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default='Game/data', help='cartella root dati')
    args = ap.parse_args()
    root = Path(args.root)
    reps = scan_folder(root)
    failed = 0
    for r in reps:
        print(r.to_text())
        print('-'*60)
        if not r.ok():
            failed += 1
    if failed:
        print(f"\nVALIDAZIONE FALLITA: {failed} file non conformi")
        sys.exit(1)
    print('\nTUTTO OK - tutti i file sono conformi')

if __name__ == '__main__':
    main()
