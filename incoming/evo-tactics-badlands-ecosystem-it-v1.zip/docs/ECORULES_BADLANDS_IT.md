# ECORULES — BADLANDS (IT)

Queste regole definiscono coperture funzionali, vincoli minimi e segnali di rischio per il bioma **Brulle Terre Ferrose**.

- **Copertura funzionale**: tutti i gruppi devono avere ≥1 specie.
- **Minimi**: `sentient ≥1`, `apex ≥1`, `keystone ≥1`, `minaccia ≥1`, `evento ≥1`, `ponte ≥1`.
- **Controlli**: top-down (apex/parasitoidi) e bottom-up (produttori/nutrienti).

**Note PTPF**
- TONE LOCK: no fantasy/steampunk/comico.
- STRUCTURE LOCK: dati in pacchetti YAML + docs.
- TELEMETRY LOCK: ogni modifica deve essere YAML-valida e tracciata.
