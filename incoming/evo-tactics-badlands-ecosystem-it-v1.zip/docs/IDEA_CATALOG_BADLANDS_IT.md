# Evo Tactics — Idea Catalog (IT) · BADLANDS

- **Tema**: ecosistema techno-bio instabile; ferro, polvere, simbiosi coercitiva.
- **Specie sensienti**: cantore_polvere (impollinatore/mediatore), regina_vesparia_ferroemato (apicale/simbionte), corvo_ferromag (ponte/osservatore).
- **Minaccia**: locusta_ferricidio (boom ciclico, defogliazione).
- **Evento**: fioritura_ferrosporo (impulso nutrienti → crash).

## Hook di encounter
- **Scorte interrotte**: il ponte (scarabeo_carovaniere) sparisce → frattura tra patch produttori.
- **Allarme polline**: calo cantori → produttori in stallo → predatori in migrazione.
- **Sciame in arrivo**: segui telemetria `risk` per dosare lo sciame di locuste.
