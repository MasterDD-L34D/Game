# Pacchetto Minimo — Evo Tactics (Bozza 2025-10-24)

### Novità in questo ampliamento
- **Biomi**: `desert.yaml`, `cavern.yaml`, `badlands.yaml` con *hazards*, preferenze specie/job e *modifiers*.
- **Regista**: schema `npg_template_schema.yaml`, esempi `npg_skirmisher_desert.yaml`, `npg_warden_cavern.yaml`, tabelle comportamento.
- **Affinità MBTI/Ennea ↔ Job**: `form/mbti_job_affinities.yaml` con micro-bonus coerenti al progetto.
- **Invoker loadout**: arma `gear/weapons/arc_rod.yaml`, tag extra `tags/weapon_extra.yaml`, surge `chain.yaml` e `pulse.yaml`.
- **Regole operative**: `rules/checklists.md`, `rules/validation.md`.

Tutto resta compatibile con i file precedenti (`species`, `morph`, `form/ENTP`, `jobs`, `rules`, `gear/twin_blades`, `tags/weapon.yaml`, `surge/pierce|spin`, `social`, `nest`, `telemetry`).

> Fonte contenuti: derivati dalle conversazioni/canvas del progetto (job set, mating/recruit, regista per biomi, MBTI/Enneagramma, preferenze e telemetria).
