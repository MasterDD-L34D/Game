# Pacchetto Minimo — Evo Tactics (Bozza 2025-10-24)

## Ampliamento v4
Questa release estende il pacchetto con contenuti emersi dai canvas/conversazioni:

- **Specie**: `sand_burrower`, `echo_wing`, `rust_scavenger` + indice `species_index.yaml`
- **Morph**: `burrow_claws`, `ferrous_carapace`, `mag_sense`, `glide_wings`, `iron_spine`, `aero_exchange`, `rust_ingest`
- **Preferenze Social**: `social/species_preferences.yaml` (Piace/Non Piace cross-biome)
- **Regista/NPG**: 6 one-pager (desert vanguard/skirmisher, cavern invoker/warden, badlands artificer/harvester)
- **Tabelle Regista**: `director/encounter_tables.yaml` + `director/regista_rewards.yaml` con numeri playtest-ready

### Come usare
1. Scegli il **bioma** e tira su `encounter_tables.yaml` per **job** e **specie**.
2. Prendi l'**NPG one-pager** corrispondente e adatta gear/traits se serve.
3. Applica **hazard/modifier** del bioma e aggiorna **telemetry** a fine turno/scene.
4. A fine incontro, assegna ricompense usando `regista_rewards.yaml` e mod di bioma.

> Tutto resta coerente con i moduli già inclusi (form/ENTP, jobs base, rules, gear, surge, social/nest, telemetria).
