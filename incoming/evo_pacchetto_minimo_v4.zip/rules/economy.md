# Economia di Progressione — Bozza

- **PE → PI**: ogni 5 PE puoi convertire in 1 PI al checkpoint di fine missione.
- **Seed Epigenetici**:
  - Fonti: Harvester (abilità), Mating riuscito, eventi bioma, boss.
  - Usi: 2 seed → respec di 1 morph di pari costo (vedi Harvester: graft_shift).
- **PP**: inizio incontro +1; max 3 salvo effetti; recupero extra via *Baratto Tecnico* (ENTP) o *scavenge_field*.
- **SG (0..3)**: si carica ogni 2 colpi messi a segno; speso per *ultimate* o surge potenziate.

**Ricompense di scena (linee guida):**
- Vittoria su élite: +1 PI, +1 seed.
- Nuova area scoperta (importante): +1 PE (sinergia *Esploratore (7)*).
- Colpo decisivo su obiettivo stage: +1 PP istantaneo (sinergia *Conquistatore (3)*).
