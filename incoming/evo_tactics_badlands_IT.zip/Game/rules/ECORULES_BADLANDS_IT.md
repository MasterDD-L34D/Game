
# Requisiti Ecosistema — Badlands (ITA)

ecosystem_rules:
  - require_full_functional_coverage: true
  - require_sentient_min: 1
  - require_apex_min: 1
  - require_keystone_min: 1
  - require_threat_min: 1      # specie 'minaccia'
  - require_event_min: 1       # specie 'evento'
  - require_bridge_min: 1      # specie 'ponte'

Specie che soddisfano:
  sentienti: [cantore_polvere, mirmec_ferro]
  apex: [dune_stalker, regina_vesparia_ferroemato]
  chiave: [dune_stalker, regina_vesparia_ferroemato]
  minaccia: [locusta_ferricidio]
  evento: [fioritura_ferrosporo]
  ponte: [scarabeo_carovaniere]
