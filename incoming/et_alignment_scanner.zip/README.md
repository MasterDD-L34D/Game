# Evo Tactics — Alignment Scanner

Questo pacchetto aggiunge uno **scanner** che legge `catalog_data.json`, JS di supporto e HTML dei report
per estrarre **specie, tag, categorie** e aggiornare i **pesi** in `config/project_index.json`.

## Uso
Copia `tools/py/scan_pack_terms.py` nel repo (alla radice o in `tools/py/`) e lancia:

```bash
python tools/py/scan_pack_terms.py --repo-root . --config config/project_index.json    # dry-run
python tools/py/scan_pack_terms.py --repo-root . --config config/project_index.json --apply
```

### Cosa fa
- Trova `catalog_data.json` in:  
  `docs/evo-tactics-pack/catalog/` **o** `packs/evo_tactics_pack/docs/catalog/`
- Se non presente, prova ad estrarre da `docs/evo-tactics-pack/pack-data.js` e `reports/overview.js`
- Scansiona anche HTML in `docs/evo-tactics-pack/reports/` e `packs/evo_tactics_pack/docs/catalog/`
- Con frequenze, assegna pesi: **5.0 (top 10%)**, **4.2 (successivo 20%)**, **3.6 (resto)**
- Unisce ai pesi esistenti mantenendo il **massimo**

### Mapping IT/EN
Vedi `docs/IT_EN_MAPPING.md`. Aggiorna quel file e/o la funzione `normalize_term()` nello script per coprire
altre varianti locali che trovi nel pack.

---

**Suggerito**: dopo `--apply`, apri una PR con titolo `feat(et-pack): auto-weights from catalog`.
