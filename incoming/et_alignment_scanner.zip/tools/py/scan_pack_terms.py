#!/usr/bin/env python3
\"\"\"
Scan Evo Tactics pack files (catalog_data.json, JS, HTML reports) and update config/project_index.json weights.
Usage:
  python tools/py/scan_pack_terms.py --repo-root . --config config/project_index.json --apply

It will:
- read catalog_data.json if present (or try to extract data from pack-data.js/overview.js)
- parse HTML reports to extract species/tags/categories (heuristics)
- compute frequencies, then assign weights (5.0 for top, 4.2 for next, 3.6 for rest)
- merge with existing weights (keeping max), write updated config (dry-run unless --apply)
\"\"\"

import os, json, re, sys
from pathlib import Path

def read_text(p):
    try:
        return Path(p).read_text(encoding='utf-8', errors='ignore')
    except Exception:
        return ""

def find_catalog_json(repo_root: Path):
    candidates = [
        repo_root / "docs" / "evo-tactics-pack" / "catalog" / "catalog_data.json",
        repo_root / "packs" / "evo_tactics_pack" / "docs" / "catalog" / "catalog_data.json",
    ]
    for c in candidates:
        if c.exists():
            return c
    return None

def parse_js_object_literals(js_text):
    tokens = set()
    for m in re.finditer(r'["\\\']([A-Za-z0-9_\\-\\s]+)["\\\']', js_text):
        s = m.group(1).strip().lower()
        if not s:
            continue
        if len(s) < 3:
            continue
        tokens.add(s)
    return tokens

def parse_html_terms(html_text):
    text = re.sub(r'<script[\\s\\S]*?</script>', ' ', html_text)
    text = re.sub(r'<style[\\s\\S]*?</style>', ' ', text)
    text = re.sub(r'<[^>]+>', ' ', text)
    words = re.findall(r'[A-Za-zÀ-ÖØ-öø-ÿ0-9_]+', text)
    terms = set()
    for w in words:
        s = w.strip().lower()
        if len(s) < 3:
            continue
        terms.add(s)
    return terms

def normalize_term(s):
    m = {
        "ecosistemi": "ecosystems",
        "ecosistema": "ecosystem",
        "bioma": "biome",
        "biomi": "biomes",
        "specie": "species",
        "rete": "network",
        "catalogo": "catalog",
        "rapporto": "report",
        "generatore": "generator",
        "piano": "plan",
        "piani": "plans",
        "torneo cremisi": "torneo cremesi",
        "torneo-cremisi": "torneo cremesi",
        "torneo-cremesi": "torneo cremesi",
        "foresta temperata": "foresta_temperata",
        "deserto caldo": "deserto_caldo"
    }
    s = s.replace('-', ' ').strip().lower()
    return m.get(s, s)

def collect_terms(repo_root: Path):
    terms = {}
    def bump(term, amount=1):
        term = normalize_term(term)
        if len(term) < 3: return
        terms[term] = terms.get(term, 0) + amount

    catalog_path = find_catalog_json(repo_root)
    if catalog_path:
        try:
            data = json.loads(read_text(catalog_path))
            for key in ("species","tags","categories","biomes","ecosystems"):
                if isinstance(data, dict) and key in data and isinstance(data[key], (list,tuple)):
                    for t in data[key]:
                        if isinstance(t, str):
                            bump(t, 4)
                if isinstance(data, dict) and key in data and isinstance(data[key], dict):
                    for t in data[key].keys():
                        bump(t, 4)
        except Exception as e:
            print(f"[warn] failed to parse {catalog_path}: {e}")

    js_candidates = [
        repo_root / "docs" / "evo-tactics-pack" / "pack-data.js",
        repo_root / "docs" / "evo-tactics-pack" / "reports" / "overview.js",
        repo_root / "packs" / "evo_tactics_pack" / "docs" / "tools" / "generator.html",
    ]
    for p in js_candidates:
        if p.exists():
            js = read_text(p)
            for t in parse_js_object_literals(js):
                bump(t, 2)

    reports_dir_1 = repo_root / "docs" / "evo-tactics-pack" / "reports"
    reports_dir_2 = repo_root / "packs" / "evo_tactics_pack" / "docs" / "catalog"
    for rdir in (reports_dir_1, reports_dir_2):
        if rdir.exists():
            for p in rdir.rglob("*.html"):
                html = read_text(p)
                for t in parse_html_terms(html):
                    bump(t, 1)

    return terms

def grade_weights(freqs: dict):
    if not freqs:
        return {}
    sorted_items = sorted(freqs.items(), key=lambda kv: kv[1], reverse=True)
    n = len(sorted_items)
    res = {}
    for i, (term, f) in enumerate(sorted_items):
        if i < max(1, int(0.10*n)):
            res[term] = 5.0
        elif i < max(2, int(0.30*n)):
            res[term] = 4.2
        else:
            res[term] = 3.6
    return res

def load_config(cfg_path: Path):
    if cfg_path.exists():
        try:
            return json.loads(Path(cfg_path).read_text(encoding='utf-8'))
        except Exception:
            return {"weights":{}, "path_bonuses":{}, "preferred_roots":[]}
    return {"weights":{}, "path_bonuses":{}, "preferred_roots":[]}

def save_config(cfg_path: Path, data: dict):
    Path(cfg_path).parent.mkdir(parents=True, exist_ok=True)
    Path(cfg_path).write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def merge_weights(existing: dict, neww: dict):
    out = dict(existing or {})
    for k, v in neww.items():
        prev = out.get(k)
        if prev is None or v > prev:
            out[k] = v
    return out

def main():
    repo_root = Path(".")
    cfg_path = Path("config/project_index.json")
    apply = False
    argv = sys.argv[1:]
    for i, a in enumerate(argv):
        if a == "--repo-root" and i+1 < len(argv):
            repo_root = Path(argv[i+1])
        if a == "--config" and i+1 < len(argv):
            cfg_path = Path(argv[i+1])
        if a == "--apply":
            apply = True

    freqs = collect_terms(repo_root)
    weights_auto = grade_weights(freqs)

    cfg = load_config(cfg_path)
    cfg.setdefault("weights", {})
    cfg["weights"] = merge_weights(cfg["weights"], weights_auto)

    print("== Preview of top 25 auto-weights ==")
    for k, v in sorted(weights_auto.items(), key=lambda kv: kv[1], reverse=True)[:25]:
        print(f"{k}: {v}")

    if apply:
        save_config(cfg_path, cfg)
        print(f"[OK] Updated {cfg_path}")
    else:
        print("[DRY-RUN] Use --apply to write changes.")

if __name__ == "__main__":
    main()
