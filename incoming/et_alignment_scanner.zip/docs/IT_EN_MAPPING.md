# IT/EN mapping (scanner & naming)

Il tool normalizza alcune varianti IT/EN per aumentare la coerenza:

- ecosistemi -> ecosystems
- ecosistema -> ecosystem
- bioma -> biome
- biomi -> biomes
- specie -> species
- rete -> network
- catalogo -> catalog
- rapporto -> report
- generatore -> generator
- piano -> plan; piani -> plans
- torneo cremisi / torneo-cremisi / torneo-cremesi -> torneo cremesi
- foresta temperata -> foresta_temperata
- deserto caldo -> deserto_caldo

Aggiungi qui varianti specifiche che trovi nel pack.
