# Risorse di Gioco (provvisorie)

- **PT (Punti Tattici)**: budget azioni per turno.
  - Cap di esempio: `pt_per_action: 2`, `pt_per_turn: 3` (vedi scheda PG).
- **PP (Punti Potenza)**: carburante per Surge, abilità o tag *Tecnico*.
  - Recupero: 1 PP all'inizio dell'incontro; max 3 salvo indicato.
  - Interazione ENTP — *Baratto Tecnico*: 1/turno converti 1 PT ↔ 1 PP.
- **PI (Punti Investimento)**: valuta di build per sbloccare job/abilità/trait.
- **PE (Punti Esperienza/Energia)**: banca progressi; convertibili in PI in checkpoint di campagna.
- **SG (Sync Gauge)**: carica tattica (0..3). Consumata da alcune Surge avanzate; ricarica a colpi messi a segno (+1 ogni 2 colpi) o evento scena.

Nota: limiti e ricariche possono essere tarati per bilanciamento in playtest.
