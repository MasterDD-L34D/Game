# Ancestors Integration Pack — v0.4 (2025-10-29)

Questa versione consolida **neurons_all.csv** con voci verificate da wiki Fandom (vedi `source_url` per ogni riga)
e aggiunge una **tabella QA** per tracciare il completamento al target **297** neuroni.

**Cosa è completo ora**
- Rami: conteggi e fonti per tutte le 18 branche (`neuronal_branches_catalog.csv`).
- Dati neuroni: esempi verificati per **Senses**, **Dexterity**, **Omnivore** (incl. trigger ed effetti).
- QA: `neurons_QA_todo.csv` mostra quante voci mancano per ogni ramo.

**Cosa resta da completare**
- Popolare i rimanenti neuroni ramo-per-ramo (Communication, Intelligence, Motricity e sub-rami, Metabolism/Medication, ecc.).

Suggerimento: procedi ramo per ramo; ogni riga deve avere:
`branch_id, neuron_id, ui_name, is_genetic, unlock_trigger, effect_short, source_url`.
