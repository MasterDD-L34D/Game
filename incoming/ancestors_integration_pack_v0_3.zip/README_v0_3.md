# Ancestors Integration Pack — v0.3 (2025-10-29)

Dati verificati da pagine Fandom/Store ufficiali (vedi `source_url` in ogni CSV).  
Questo drop include tabelle **pulite** per import nel tuo DB.

## File
- `evolution_milestones.csv` — specie/leap con finestra temporale (~Mya) e giocabilità.
- `neuronal_branches.csv` — lista completa dei rami (6 primari + 12 sub) con **conteggi**.
- `neurons_samples.csv` — esempi reali per 2 rami (Senses/Dexterity) con nomi UI.
- `genetic_mutations_summary.csv` — regole d’acquisizione e conteggio **89** mutazioni.
- `meteorite_sites.csv` — **12** siti meteorite nominali.
- `evolution_feats_examples.csv` — esempi con condizioni sintetiche (Explore/Expand/Evolve).

> Per il **dump totale dei neuroni (297)** si consiglia scraping guidato ramo-per-ramo, mantenendo `branch_id`,
> `ui_name`, `is_genetic`, `prereq`, `unlock_trigger`, `effect_short`, `source_url`.

