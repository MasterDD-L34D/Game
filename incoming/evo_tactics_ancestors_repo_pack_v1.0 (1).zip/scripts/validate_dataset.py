#!/usr/bin/env python3
import pandas as pd
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
data = ROOT / "data"

branches = pd.read_csv(data / "neuronal_branches_catalog.csv")
neurons = pd.read_csv(data / "neurons_all.csv")

# Normalize branch ids
b_expected = {row.branch_id: (row.total_neurons or 0) for _, row in branches.iterrows() if pd.notna(row.total_neurons)}
present = neurons.groupby("branch_id")["neuron_id"].nunique().to_dict()

lines = ["# Validation Report\n"]
total_expected = sum(b_expected.values())
total_present = len(neurons)

lines.append(f"- Expected neurons (sum of branches with known totals): {total_expected}")
lines.append(f"- Present neurons in file: {total_present}\n")

lines.append("| Branch | Expected | Present | Missing |")
lines.append("|---|---:|---:|---:|")
for bid, exp in sorted(b_expected.items()):
    pres = present.get(bid, 0)
    miss = int(exp) - int(pres)
    lines.append(f"| `{bid}` | {exp} | {pres} | {miss} |")

out = ROOT / "docs" / "validation_report.md"
out.write_text("\n".join(lines), encoding="utf-8")
print(f"Wrote {out}")
