# CITATIONS (fonti principali)

- Evolution (milestone/specie): https://ancestors.fandom.com/wiki/Evolution
- Neuronal overview & counts: https://ancestors.fandom.com/wiki/Neuronal
- Senses branch: https://ancestors.fandom.com/wiki/Senses_(neuronal_branch)
- Dexterity branch: https://ancestors.fandom.com/wiki/Dexterity_(neuronal_branch)
- Communication actions: Clan's Call https://ancestors.fandom.com/wiki/Clan%27s_Call ; Switch Hands https://ancestors.fandom.com/wiki/Switch_Hands
- Omnivore branch: https://ancestors.fandom.com/wiki/Omnivore_(neuronal_branch)
- Meteorites: https://ancestors.fandom.com/wiki/Meteorite_Site
- Genetic Mutations: https://ancestors.fandom.com/wiki/Genetic_Mutations ; Neurons https://ancestors.fandom.com/wiki/Neurons
- Combat/Counterattack/Striking/Dodge: https://ancestors.fandom.com/wiki/Combat ; https://ancestors.fandom.com/wiki/Counterattack ; https://ancestors.fandom.com/wiki/Striking ; https://ancestors.fandom.com/wiki/Dodge
- Self-Control (icons reference): https://ancestors.fandom.com/wiki/Category:Self-Control_neurons_icons
