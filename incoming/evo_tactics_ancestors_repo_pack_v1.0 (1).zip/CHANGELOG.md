# Changelog

## v1.0 (2025-10-29)
- Impacchettata struttura repo-ready con dati CSV, YAML tratti *Sensienti*, schemi JSON, script di validazione.
- Dump neuroni: Omnivore (completo), Attack/Dodge/Self-Control (completi), Senses/Dexterity (subset ricco), Ambulation (inizio).
- Aggiunti milestone evolutivi, meteore/mutazioni, feat d'esempio.
