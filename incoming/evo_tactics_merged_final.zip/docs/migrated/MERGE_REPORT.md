# MERGE REPORT — evo-tactics (nostro) vs incoming

## Riepilogo

- File solo nostri: 10
- File solo incoming: 99
- File comuni: 0 (differenti: 0)

### Aggiunti dall'incoming:

- `GM_Quickstart.md`
- `README_MIN_PACCHETTO.md`
- `biomes/badlands.yaml`
- `biomes/cavern.yaml`
- `biomes/desert.yaml`
- `biomes/starter_biomes.yaml`
- `director/behavior_tables.md`
- `director/encounter_tables.yaml`
- `director/npg_artificer_badlands.yaml`
- `director/npg_harvester_badlands.yaml`
- `director/npg_invoker_cavern.yaml`
- `director/npg_skirmisher_desert.yaml`
- `director/npg_template_schema.yaml`
- `director/npg_vanguard_desert.yaml`
- `director/npg_warden_cavern.yaml`
- `director/regista.md`
- `director/regista_rewards.yaml`
- `docs/Quickstart_GM.md`
- `ennea/themes.yaml`
- `exports/spawn_packs/pack_biome_jobs_v1.json`
- `form/ENTP.yaml`
- `form/mbti_gates.yaml`
- `form/mbti_job_affinities.yaml`
- `gear/weapons/arc_rod.yaml`
- `gear/weapons/twin_blades.yaml`
- `jobs/artificer.yaml`
- `jobs/harvester.yaml`
- `jobs/invoker.yaml`
- `jobs/skirmisher.yaml`
- `jobs/vanguard.yaml`
- `jobs/warden.yaml`
- `manifest.json`
- `modules/personality/enneagram/HOWTO_EVO_TACTICS.md`
- `modules/personality/enneagram/README_ADDON_PER_PACCHETTO.md`
- `modules/personality/enneagram/README_ENNEAGRAMMA.md`
- `modules/personality/enneagram/README_INTEGRAZIONE_MECCANICHE.md`
- `modules/personality/enneagram/compat_map.json`
- `modules/personality/enneagram/enneagramma_dataset.json`
- `modules/personality/enneagram/enneagramma_schema.json`
- `modules/personality/enneagram/hook_bindings.ts`
- `modules/personality/enneagram/personality_module.v1.json`
- `modules/personality/enneagram/pg_enneagram_template.yaml`
- `morph/acid_gland.yaml`
- `morph/aero_exchange.yaml`
- `morph/burrow_claws.yaml`
- `morph/burst_anaerobic.yaml`
- `morph/echolocate.yaml`
- `morph/elastomer_skin.yaml`
- `morph/ferrous_carapace.yaml`
- `morph/glide_wings.yaml`
- `morph/iron_spine.yaml`
- `morph/mag_sense.yaml`
- `morph/rust_ingest.yaml`
- `morph/spring_legs.yaml`
- `nest/requirements.yaml`
- `pc_fix_snippet.yaml`
- `rules/checklists.md`
- `rules/checks.md`
- `rules/economy.md`
- `rules/job_gates.yaml`
- `rules/mating_biome_links.md`
- `rules/preferences_tables.md`
- `rules/privacy.md`
- `rules/proficiency.md`
- `rules/resources.md`
- `rules/stances.yaml`
- `rules/stats.md`
- `rules/synergies.yaml`
- `rules/tuning.md`
- `rules/units_grid.md`
- `rules/validation.md`
- `schema/npg_schema.json`
- `schema/pc_schema.json`
- `schemas/npg.schema.json`
- `schemas/pg.schema.json`
- `scripts/spawn_npg.py`
- `scripts/validate_package.py`
- `social/affinity_trust.md`
- `social/mating.md`
- `social/species_preferences.yaml`
- `species/dune_stalker.yaml`
- `species/echo_wing.yaml`
- `species/rust_scavenger.yaml`
- `species/sand_burrower.yaml`
- `species/species_index.yaml`
- `surge/chain.yaml`
- `surge/overdrive.yaml`
- `surge/pierce.yaml`
- `surge/pulse.yaml`
- `surge/spin.yaml`
- `tags/weapon.yaml`
- `tags/weapon_advanced.yaml`
- `tags/weapon_extra.yaml`
- `telemetry/pf_session.yaml`
- `telemetry/vc.yaml`
- `tools/validate_v7.py`
- `traits/backstab.yaml`
- `traits/focus_frazionato.yaml`
- `vtt/npg_pack.json`

## Validator

- species.yaml: OK
```json
{
  "species": [
    {
      "id": "dune_stalker",
      "errors": [],
      "warnings": []
    }
  ],
  "errors": 0,
  "warnings": 0
}
```
- forms.yaml: ERROR
```json
{
  "errors": [
    "ENTP: PI cost sum = 5 (must equal 7)"
  ],
  "forms_ui": [
    {
      "code": "ENTP",
      "cost": 5
    }
  ]
}
```